import 'package:flutter/material.dart';

class GiftCardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Gift Card')),
      body: Center(child: Text('Gift Card Page')),
    );
  }
}
