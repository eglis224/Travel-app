package com.ghurafira.app.ghurafira

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
